class LoopLocalAPI {
  constructor() {
    this.API_BASE = 'https://web-production-5630.up.railway.app/v1';
    this.setupMessageHandlers();
    this.initializeAuth();
  }

  setupMessageHandlers() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      switch (request.action) {
        case 'SAVE_POST':
          this.handleSavePost(request.data).then(sendResponse);
          return true;
        
        case 'GET_SAVED_ITEMS':
          this.getSavedItems(request.filters).then(sendResponse);
          return true;
          
        case 'CHECK_AUTH':
          this.checkAuth().then(sendResponse);
          return true;
      }
    });
  }

  async initializeAuth() {
    // Clear any existing badge
    chrome.action.setBadgeText({ text: '' });

    const authToken = await chrome.storage.local.get(['authToken']);
    if (!authToken.authToken) {
      // Badge notifications disabled
      // chrome.action.setBadgeText({ text: '!' });
      // chrome.action.setBadgeBackgroundColor({ color: '#ff4444' });
    }
  }

  async handleSavePost(postData) {
  try {
    console.log('🔄 Sending to AI backend:', postData);

    // Badge notifications disabled
    // chrome.action.setBadgeText({ text: '...' });
    // chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });

    // Call AI backend
    const response = await fetch(`${this.API_BASE}/analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        platform: postData.platform,
        url: postData.url,
        content: postData.content,
        images: postData.images,
        author: postData.author
      })
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.status}`);
    }

    const result = await response.json();
    console.log('✅ AI Analysis Result:', result);

    if (result.success) {
      // Save with AI-enhanced data
      await this.saveLocallyWithAI(postData, result.data);

      // Badge notifications disabled
      // const count = await this.getSavedItemsCount();
      // chrome.action.setBadgeText({ text: count > 99 ? '99+' : count.toString() });

      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon48.png',
        title: '🎉 Saved with AI!',
        message: result.data.event_name || result.data.venue_name || 'Post analyzed and saved'
      });

      return { success: true, item: result.data };
    } else {
      throw new Error(result.error || 'Analysis failed');
    }
    
  } catch (error) {
    console.error('❌ Save failed:', error);

    // Badge notifications disabled
    // chrome.action.setBadgeText({ text: 'X' });
    // chrome.action.setBadgeBackgroundColor({ color: '#ff4444' });

    // Fallback to local save if API fails
    console.log('⚠️ Falling back to local save...');
    return await this.saveLocally(postData);
  }
}

async saveLocallyWithAI(postData, aiData) {
  const storage = await chrome.storage.local.get(['savedItems']);
  const savedItems = storage.savedItems || [];

  const newItem = {
    id: Date.now().toString(),
    ...postData,
    // Use user-provided data first, then AI-enhanced fields as fallback
    event_name: postData.event_name || aiData.event_name || this.extractTitle(postData.content),
    venue_name: postData.venue_name || aiData.venue_name || null,
    address: postData.address || aiData.address || null,
    event_date: postData.event_date || aiData.event_date || null,
    start_time: aiData.start_time,
    end_time: aiData.end_time,
    event_type: aiData.event_type,
    tags: aiData.suggested_tags || [],
    description: aiData.description,
    is_recurring: aiData.is_recurring,
    recurrence_pattern: aiData.recurrence_pattern,
    ai_processed: true,
    confidence_score: aiData.confidence_score,
    saved_at: new Date().toISOString()
  };

  savedItems.unshift(newItem);
  await chrome.storage.local.set({ savedItems: savedItems.slice(0, 100) });

  return { success: true, data: newItem };
}

  async saveLocally(postData) {
    const storage = await chrome.storage.local.get(['savedItems']);
    const savedItems = storage.savedItems || [];

    const newItem = {
      id: Date.now().toString(),
      ...postData,
      saved_at: new Date().toISOString(),
      // Use user-provided data first, then extract from content as fallback
      event_name: postData.event_name || this.extractTitle(postData.content),
      venue_name: postData.venue_name || null,
      tags: []
    };

    savedItems.unshift(newItem);

    await chrome.storage.local.set({
      savedItems: savedItems.slice(0, 100)
    });

    return { success: true, data: newItem };
  }

  extractTitle(content) {
    if (!content) return 'Saved Post';
    const firstSentence = content.split(/[.!?]/)[0];
    return firstSentence.substring(0, 50) + (firstSentence.length > 50 ? '...' : '');
  }

  async getSavedItems(filters = {}) {
    const storage = await chrome.storage.local.get(['savedItems']);
    return { items: storage.savedItems || [] };
  }

  async getSavedItemsCount() {
    const result = await this.getSavedItems();
    return result.items.length;
  }

  async checkAuth() {
    return { 
      user: { 
        id: 'demo-user', 
        email: 'demo@looplocal.com' 
      } 
    };
  }
}

new LoopLocalAPI();